# prepare_data.py
# Step 0: clean the given dataset and add the columns the 3 tasks need
# (employee id, name, department, productivity scores).
# Run it with:  python prepare_data.py

import pandas as pd
import random

random.seed(42)   # same random numbers every time we run it

# ---------- 1. load the file ----------
df = pd.read_csv("salary_synthetic.csv")
print("rows loaded:", len(df))

# ---------- 2. fill the missing values ----------
# numbers -> use the median, text -> use the most common value
df["experience_years"] = df["experience_years"].fillna(df["experience_years"].median())
df["skills_count"] = df["skills_count"].fillna(df["skills_count"].median())
df["certifications"] = df["certifications"].fillna(0)
df["last_promotion_years_ago"] = df["last_promotion_years_ago"].fillna(df["last_promotion_years_ago"].median())
df["recent_project_description_length"] = df["recent_project_description_length"].fillna(
    df["recent_project_description_length"].median())
df["education"] = df["education"].fillna(df["education"].mode()[0])
df["recent_note"] = df["recent_note"].fillna("No relevant project mentioned")

# ---------- 3. employee id ----------
df["employee_id"] = ["EMP" + str(i + 1).zfill(4) for i in range(len(df))]

# ---------- 4. fake names ----------
male_names = ["Rahim", "Karim", "Hasan", "Imran", "Sabbir", "Tanvir", "Arif", "Nayeem", "Rafi", "Fahim", "Mahin", "Shakil"]
female_names = ["Nusrat", "Sadia", "Farhana", "Tania", "Mim", "Rima", "Jannat", "Sumaiya", "Nabila", "Ayesha", "Priya", "Lamia"]
last_names = ["Ahmed", "Hossain", "Islam", "Rahman", "Chowdhury", "Khan", "Uddin", "Sarker", "Mia", "Akter", "Das", "Roy"]

def make_name(gender):
    if gender == "Male":
        first = random.choice(male_names)
    elif gender == "Female":
        first = random.choice(female_names)
    else:
        first = random.choice(male_names + female_names)
    return first + " " + random.choice(last_names)

df["name"] = df["gender"].apply(make_name)

# ---------- 5. department ----------
# use the project note when we can, otherwise pick a random one
def get_department(note):
    if note == "Built ML pipeline for preprocessing":
        return "Data Science"
    if note == "Contributed to open-source NLP repo":
        return "Data Science"
    if note == "Worked on microservices deployment":
        return "Engineering"
    if note == "Experience in data cleaning and ETL":
        return "Data Engineering"
    return random.choice(["HR", "Finance", "Marketing", "Sales", "Operations"])

df["department"] = df["recent_note"].apply(get_department)

# ---------- 6. productivity scores (0 - 100) ----------
# engagement  -> skills + certifications + remote work
# efficiency  -> how recently promoted and how long they have worked
# output      -> project description length and skills
def limit(x):
    return max(0, min(100, round(x)))

engagement, efficiency, output = [], [], []
for i, row in df.iterrows():
    e = 40 + row["skills_count"] * 4 + row["certifications"] * 5 + random.randint(-10, 15)
    f = 80 - row["last_promotion_years_ago"] * 5 + row["experience_years"] * 0.8 + random.randint(-12, 8)
    o = 20 + row["recent_project_description_length"] * 0.7 + row["skills_count"] * 3 + random.randint(-10, 10)
    engagement.append(limit(e))
    efficiency.append(limit(f))
    output.append(limit(o))

df["engagement"] = engagement
df["efficiency"] = efficiency
df["output"] = output
df["productivity_score"] = ((df["engagement"] + df["efficiency"] + df["output"]) / 3).round()

# High / Medium / Low
def get_level(score):
    if score >= 76:
        return "High"
    elif score >= 69:
        return "Medium"
    else:
        return "Low"

df["productivity_level"] = df["productivity_score"].apply(get_level)
print(df["productivity_level"].value_counts())

# ---------- 7. save the cleaned csv ----------
df = df[["employee_id", "name", "gender", "age", "department", "role_seniority", "education",
         "experience_years", "company_size", "location_tier", "worked_remote", "skills_count",
         "certifications", "last_promotion_years_ago", "salary_bdt", "engagement", "efficiency",
         "output", "productivity_score", "productivity_level"]]
df.to_csv("employee_data.csv", index=False)

# ---------- 8. make a .js file so the html pages can read the data ----------
# (browsers can't read a csv from a local file, so we put the data inside a js file)
df.to_json("employee_data.json", orient="records")
with open("employee_data.json") as f:
    text = f.read()
with open("employee_data.js", "w") as f:
    f.write("// auto-made by prepare_data.py\nconst employees = " + text + ";\n")

print("done! saved employee_data.csv and employee_data.js")
