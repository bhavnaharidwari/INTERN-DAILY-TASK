SalaryInsight - 3 tasks
=======================
Each html file is now standalone (the data is inside it).
Just double-click any task html file to open it in Chrome/Edge/Firefox.

task1_search_bar.html            Task 1 - search by name, ID or department (click a row for details)
task2_productivity_filter.html   Task 2 - filter by productivity level and engagement/efficiency/output score
task3_responsive_ui.html         Task 3 - full page that works on mobile, tablet and desktop

prepare_data.py                  cleans salary_synthetic.csv and adds ID, name, department, productivity columns
employee_data.csv                the new dataset (open in Excel to see it)
employee_data.js                 same data as a js file (only needed if you rebuild the pages)
